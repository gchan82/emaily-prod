//dev.js -- don't commit this!!!

module.exports = {
  googleClientID: '526206735091-in3vp134trqi1m58hvuqeh8jl4q1i2gn.apps.googleusercontent.com',
  googleClientSecret: 'vRLPQNQYYvxC70PYokxloyqB',
  mongoURI: 'mongodb://gary:pass123@ds147942.mlab.com:47942/emaily-dev',
  cookieKey: 'cookiekeyrandomletterssdgiaohapdhnalkaysgiandjolghlkdfhagi'
};